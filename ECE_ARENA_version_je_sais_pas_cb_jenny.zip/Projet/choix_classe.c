//
// Created by alois on 18/05/2025.
//


#include "choix_classe.h"

void choix_perso(BITMAP* buffer, init_joueurs* j, int id_joueur) {
    int page_actuelle = 0;
    BITMAP* image1 = load_bitmap("savant.bmp", NULL);
    BITMAP* image2 = load_bitmap("archere.bmp", NULL);
    BITMAP* image3 = load_bitmap("mage.bmp", NULL);
    BITMAP* image4 = load_bitmap("maitresse_dragon.bmp", NULL);
    BITMAP* fond_transition = load_bitmap("arene_mystique.bmp", NULL); // 🎯 fond d'écran pour le texte

    int selection_x = 0, selection_y = 0, selection_w = 0, selection_h = 0;

    while (page_actuelle == 0) {
        clear_bitmap(buffer);

        // Titre
        char titre[32];
        sprintf(titre, "Choix du joueur %d", id_joueur + 1);
        textout_centre_ex(buffer, font, titre, SCREEN_W / 2, 20, makecol(255, 255, 0), -1);

        // Affichage des images
        draw_sprite(buffer, image1, 50, 50);
        draw_sprite(buffer, image2, 50, 310);
        draw_sprite(buffer, image3, 410, 50);
        draw_sprite(buffer, image4, 410, 310);

        // Gestion du clic
        if (mouse_b & 1) {
            if (mouse_x >= 50 && mouse_x <= 50 + image1->w && mouse_y >= 50 && mouse_y <= 50 + image1->h) {
                page_actuelle = 'A';
                selection_x = 50; selection_y = 50;
                selection_w = image1->w; selection_h = image1->h;
            } else if (mouse_x >= 50 && mouse_x <= 50 + image2->w && mouse_y >= 310 && mouse_y <= 310 + image2->h) {
                page_actuelle = 'B';
                selection_x = 50; selection_y = 310;
                selection_w = image2->w; selection_h = image2->h;
            } else if (mouse_x >= 410 && mouse_x <= 410 + image3->w && mouse_y >= 50 && mouse_y <= 50 + image3->h) {
                page_actuelle = 'C';
                selection_x = 410; selection_y = 50;
                selection_w = image3->w; selection_h = image3->h;
            } else if (mouse_x >= 410 && mouse_x <= 410 + image4->w && mouse_y >= 310 && mouse_y <= 310 + image4->h) {
                page_actuelle = 'D';
                selection_x = 410; selection_y = 310;
                selection_w = image4->w; selection_h = image4->h;
            }

            rest(200); // anti-rebond
        }

        blit(buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
        rest(16);
    }

    // Enregistre la classe choisie
    const char* nom_classe = "";
    switch (page_actuelle) {
        case 'A': nom_classe = "Savant"; break;
        case 'B': nom_classe = "Archere"; break;
        case 'C': nom_classe = "Mage"; break;
        case 'D': nom_classe = "Maitresse"; break;
    }
    strcpy(j->nom, nom_classe);
    j->classe[0] = page_actuelle;
    j->classe[1] = '\0';

    // Affiche un cadre jaune autour de la sélection
    rect(buffer, selection_x - 2, selection_y - 2, selection_x + selection_w + 2, selection_y + selection_h + 2, makecol(255, 255, 0));
    blit(buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
    rest(600);

    // Transition avec fond d'écran et texte
    if (fond_transition) {
        draw_sprite(buffer, fond_transition, 0, 0);
    } else {
        clear_bitmap(buffer); // Si l'image est introuvable, on efface l'écran
    }

    char texte_transition[64];
    sprintf(texte_transition, "Joueur %d a choisi %s", id_joueur + 1, nom_classe);
    textout_centre_ex(buffer, font, texte_transition, SCREEN_W / 2, SCREEN_H / 2 - 10, makecol(255, 255, 255), -1);


    blit(buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
    rest(1500); // Pause visible

    // Libération mémoire
    destroy_bitmap(image1);
    destroy_bitmap(image2);
    destroy_bitmap(image3);
    destroy_bitmap(image4);
    if (fond_transition) destroy_bitmap(fond_transition);
}



