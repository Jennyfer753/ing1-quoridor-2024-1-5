//
// Created by alois on 18/05/2025.
//

#include "temps_jeu.h"

// Variables internes au module (le code a surtout été pris de internet et changé par chatgpt)
// mais refait pour etre utile dans notre projet
static clock_t start_time = 0;
static int secondes = 0;

// Fonction d'affichage et de logique du minuteur
int temps(BITMAP* buffer) {
    char temps_str[10];

    if (start_time == 0)
        start_time = clock();  // Initialisation au premier appel du temps

    clock_t elapsed = (clock() - start_time) / CLOCKS_PER_SEC; // Calcule le temps écoulé depuis le début, en secondes
    //Si le temps écoulé est supérieur à la valeur actuelle de "secondes",
    // on met à jour "secondes" pour qu'il reflète le temps écoulé actuel
    if (elapsed > secondes)
        secondes = elapsed;

    // Dessin du rectangle rouge et du compteur
    rectfill(buffer, 740, 25, 775, 40, makecol(255, 0, 0));
    sprintf(temps_str, "%02d", secondes);


    // Retourne 1 si 15 secondes écoulées
    if (secondes >= 15) {
        secondes = 0;
        start_time = clock();  // Redémarrer le compteur à 0 par rapport au temps actuelle
        return 1;
    }

    return 0;
}

// Fonction à appeler pour réinitialiser le chrono manuellement
void reinit_temps() {
    start_time = 0;
    secondes = 0;
}
