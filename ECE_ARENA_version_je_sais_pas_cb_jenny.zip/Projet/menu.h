//
// Created by alois on 18/05/2025.
//

#ifndef MENU_H
#define MENU_H

#include<allegro.h>
BITMAP* charger_img_menu();
void ecran_menu(BITMAP* buffer, BITMAP* img_menu);

#endif //MENU_H
