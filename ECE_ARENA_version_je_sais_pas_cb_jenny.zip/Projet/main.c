#include <stdio.h>
#include <allegro.h>
#include "allegro_init.h"
#include "menu.h"
#include "parties.h"
#include "gestion_sons.h"
#include "temps_jeu.h"

#include "gestion_jeu.h"

int main() {
    lancer_jeu();
    return 0;
}
END_OF_MAIN();