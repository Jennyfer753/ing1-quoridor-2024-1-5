//
// Created by alois on 18/05/2025.
//


#ifndef ATTAQUE_SORT_H
#define ATTAQUE_SORT_H
/*
#include <allegro.h>


#define NBR_SORTS 4


// Déclaration des tableaux de sorts par classe
extern Sort maitresse[NBR_SORTS];
extern Sort savant[NBR_SORTS];
extern Sort mage[NBR_SORTS];
extern Sort archere[NBR_SORTS];

// Fonctions d'initialisation
void init_sorts_classes(void);
void init_personnage_maitresse(init_joueurs* p);
void init_personnage_savant(init_joueurs* p);

// Fonctions utilitaires
int distance(int x1, int y1, int x2, int y2);
int est_dans_portee(init_joueurs* lanceur, init_joueurs* cible, Sort* s);
int peut_utiliser_sort(init_joueurs* p, Sort* s);
void utiliser_sort(init_joueurs* lanceur, init_joueurs* cible, Sort* s);
*/

#endif // ATTAQUE_SORT_H