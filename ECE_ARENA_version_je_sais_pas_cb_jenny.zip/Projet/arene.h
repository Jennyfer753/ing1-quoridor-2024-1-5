//
// Created by alois on 18/05/2025.
//

#ifndef ARENE_H
#define ARENE_H
#include "joueurs.h"
#include <allegro.h>


int arene(BITMAP* buffer, init_joueurs* j);


#endif //ARENE_H
