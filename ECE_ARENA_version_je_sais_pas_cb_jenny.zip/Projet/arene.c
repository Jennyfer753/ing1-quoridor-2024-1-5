//
// Created by alois on 18/05/2025.
//

#include "arene.h"
#include <stdio.h>
#include <allegro.h>
#include "arene.h"
#include <stdio.h>
#include <allegro.h>

int arene(BITMAP* buffer, init_joueurs* j) {
    int arene[15][15] = {0};
    int taille_case = 40;
    int nb_lignes = 13;
    int nb_colonnes = 15;

    int decalage_x = 20;
    int decalage_y = (600 - nb_lignes * taille_case) / 2;

    static int joueur_actif = 0;  // 0 = joueur a, 1 = joueur b

    // --- GRILLE ---
    for (int ligne = 0; ligne < nb_lignes; ligne++) {
        for (int colonne = 0; colonne < nb_colonnes; colonne++) {
            int x = decalage_x + colonne * taille_case;
            int y = decalage_y + ligne * taille_case;

            int couleur;
            if (arene[ligne][colonne] == 0) {
                couleur = makecol(0, 0, 0);
            } else {
                couleur = makecol(100, 100, 100);
            }

            rectfill(buffer, x, y, x + taille_case - 1, y + taille_case - 1, couleur);
            rect(buffer, x, y, x + taille_case - 1, y + taille_case - 1, makecol(255, 255, 255));
        }
    }

    // === BOUTONS INTÉGRÉS À L'ARÈNE ===
    int rx = decalage_x + nb_colonnes * taille_case + 15;
    int largeurG = 150;
    int hauteurG = 50;

    int ry1 = decalage_y;
    int ry2 = ry1 + hauteurG + 25;

    int largeurP = 120;
    int hauteurP = 40;
    int espacementP = 15;

    int px_petits = rx;
    int py_start = ry2 + hauteurG + 30;
    int ryFinal = py_start + 4 * (hauteurP + espacementP) + 20;

    textprintf_centre_ex(buffer, font, rx + largeurG/2, decalage_y - 50, makecol(255,255,255), -1, "ACTIONS POSSIBLES :");

    // Premier bouton actif (attaque CAC)
    rectfill(buffer, rx, ry1, rx + largeurG, ry1 + hauteurG, makecol(150, 0, 0));
    rect(buffer, rx, ry1, rx + largeurG, ry1 + hauteurG, makecol(255, 255, 255));
    textprintf_centre_ex(buffer, font, rx + largeurG/2, ry1 + hauteurG/2 - text_height(font)/2, makecol(255,255,255), -1, "Attaque proche");

    // Deuxième bouton inactif
    rectfill(buffer, rx, ry2, rx + largeurG, ry2 + hauteurG, makecol(80, 80, 80));
    rect(buffer, rx, ry2, rx + largeurG, ry2 + hauteurG, makecol(150, 150, 150));
    textprintf_centre_ex(buffer, font, rx + largeurG/2, ry2 + hauteurG/2 - text_height(font)/2, makecol(200,200,200), -1, "Attaque sort");

    // Petits boutons
    for (int i = 0; i < 4; i++) {
        int py = py_start + i * (hauteurP + espacementP);
        rectfill(buffer, px_petits, py, px_petits + largeurP, py + hauteurP, makecol(0, 80, 150));
        rect(buffer, px_petits, py, px_petits + largeurP, py + hauteurP, makecol(255, 255, 255));

        char label[20];
        sprintf(label, "petit %d", i+1);
        textout_centre_ex(buffer, font, label, px_petits + largeurP/2, py + 10, makecol(255, 255, 255), -1);
    }

    // Dernier bouton : Sauter son tour
    rectfill(buffer, rx, ryFinal, rx + largeurG, ryFinal + hauteurG, makecol(0, 150, 0));
    rect(buffer, rx, ryFinal, rx + largeurG, ryFinal + hauteurG, makecol(255, 255, 255));
    textprintf_centre_ex(buffer, font, rx + largeurG/2, ryFinal + hauteurG/2 - text_height(font)/2, makecol(255,255,255), -1, "Sauter son tour");

    // Affichage du joueur actif
    char info[50];
    sprintf(info, "Joueur %d joue !", joueur_actif + 1);
    rectfill(buffer, rx, ryFinal + hauteurG + 10, rx + largeurG, ryFinal + hauteurG + 35, makecol(0, 0, 80));
    textout_centre_ex(buffer, font, info, rx + largeurG / 2, ryFinal + hauteurG + 15, makecol(255, 255, 0), -1);

    // Gestion clic
    if (mouse_b & 1) {
        int mx = mouse_x;
        int my = mouse_y;

        if (mx >= rx && mx <= rx + largeurG && my >= ryFinal && my <= ryFinal + hauteurG) {
            rest(150);
            while (mouse_b & 1) rest(1);
            return 1; // On a cliqué sur "Sauter son tour"
        }
    }

    return 0; // Aucun clic
}
