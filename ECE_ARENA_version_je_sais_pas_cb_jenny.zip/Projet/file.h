//
// Created by alois on 18/05/2025.
//

#ifndef FILE_H_INCLUDED
#define FILE_H_INCLUDED
///type pour les maillons
typedef struct maillonF{
    void *data; //pointeur g�n�rique sur la donn�e
    struct maillonF *suivant;  //pointeur sur le maillon suivant
}t_maillonF;

///type pour la file
typedef struct file{
    t_maillonF *tete;//ancre de t�te : pointeur sur le prochain maillon � d�filer
    t_maillonF *fin;//ancre de fin : pointeur sur le dernier maillon (apr�s lequel enfiler)
}t_file;

///prototypes des sous-programmes

/* initialisation d'une file vide
param�tre : l'adresse de la file */
void init_file(t_file*f);

/* test si la file est vide
param�tre : l'adresse de la file
retour : 1 si la file est vide, 0 sinon */
int fileVide(t_file*f);

/* compter le nombre d'�l�ments
param�tre : l'adresse de la file
retour : taille de la file */
int tailleF(t_file*f);

/* enfiler une nouvelle donn�e
param�tres : l'adresse de la file, l'adresse de la donn�e */
void enfiler(t_file*f,void*data);

/* d�filer le prochain �lement
param�tre : l'adresse de la file
retour : l'adresse de la donnee*/
void* defiler(t_file*f);

/* acceder au prochain element (donn�e en t�te)
param�tre : l'adresse de la file
retour : adresse de la donn�e en t�te */
void* tete(t_file*f);

#endif // FILE_H_INCLUDED
