//
// Created by alois on 18/05/2025.
//
/*
#include <stdio.h>
#include "attaque_corps.h"
#include "attaque_sort.h"

void afficherNuageFumee(int x, int y);  // Corrigé aussi l'en-tête de fonction

// Vérifie si les personnages sont sur des cases voisines
int sontAdjacents(init_joueurs* j, ClassePersonnage *b) {
    if (abs(a->x - b->x) + abs(a->y - b->y) == 1) {
        return 1;
    }
    return 0;
}

void attaqueCAC(ClassePersonnage *a, ClassePersonnage *b) {
    if (sontAdjacents(a, b)) {

        // Sauvegarde la position de a
        int oldX = a->x;
        int oldY = a->y;

        // a fonce sur b
        a->x = b->x;
        a->y = b->y;

        // Affiche le nuage de fumée
        afficherNuageFumee(b->x, b->y);

        // Appliquer les dégâts (décommenter si nécessaire)
        // b->pv -= a->puissanceCAC;

        // Retour à la position initiale
        a->x = oldX;
        a->y = oldY;
    } else {
        printf("Pas à portée !\n");
    }
}

*/