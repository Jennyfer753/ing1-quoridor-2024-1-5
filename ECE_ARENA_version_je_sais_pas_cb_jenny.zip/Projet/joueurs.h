//
// Created by alois on 18/05/2025.
//

#ifndef JOUEURS_H
#define JOUEURS_H
#include "attaque_sort.h"

/*
// Structure d'un sort
typedef struct {
    char nom[50];
    int degats_min;
    int degats_max;
    int pa_requis;
    int portee_min;
    int portee_max;
    int chance_echec;  // en pourcentage
    int zone;
} Sort;
*/

typedef struct {
    int ligne;
    int colonne;
    int couleur;
    int pv ;
    int pm;
    int pa;
    char classe[20];
    char nom[51];
    //Sort sorts[NBR_SORTS];  // ajoute ça
} init_joueurs;



#endif //JOUEURS_H
