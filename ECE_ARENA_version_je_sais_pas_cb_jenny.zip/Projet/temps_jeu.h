//
// Created by alois on 18/05/2025.
//

#ifndef TEMPS_JEU_H
#define TEMPS_JEU_H
#include "parties.h"
#include <allegro.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int temps(BITMAP* buffer);
void reinit_temps();

#endif //TEMPS_JEU_H
