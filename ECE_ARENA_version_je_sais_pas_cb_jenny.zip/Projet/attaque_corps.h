//
// Created by alois on 18/05/2025.
//
/*
#ifndef ATTAQUE_CORPS_H

#define ATTAQUE_CORPS_H
void afficherNuageFumee(int x, int y);  // Corrigé aussi l'en-tête de fonction
int sontAdjacents(init_joueurs* j, ClassePersonnage *b);
void attaqueCAC(ClassePersonnage *a, ClassePersonnage *b);
*/
#endif //ATTAQUE_CORPS_H
