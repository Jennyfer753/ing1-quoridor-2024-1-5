//
// Created by alois on 18/05/2025.
//
/*
#include "attaque_sort.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define NBR_SORTS 4




// Déclarations des tableaux de sorts pour chaque classe
Sort maitresse[NBR_SORTS];
Sort savant[NBR_SORTS];
Sort mage[NBR_SORTS];
Sort archere[NBR_SORTS];

// Initialisation des sorts de la Maitresse
void init_maitresse_1(Sort* s) {
    strcpy(s->nom, "Bébé dragon");
    s->degats_min = 2;
    s->degats_max = 3;
    s->pa_requis = 2;
    s->portee_min = 1;
    s->portee_max = 3;
    s->chance_echec = 5;
    s->zone = 0;
}
void init_maitresse_2(Sort* s) {
    strcpy(s->nom, "Multiple boule de feu");
    s->degats_min = 3;
    s->degats_max = 4;
    s->pa_requis = 3;
    s->portee_min = 1;
    s->portee_max = 4;
    s->chance_echec = 5;
    s->zone = 0;
}
void init_maitresse_3(Sort* s) {
    strcpy(s->nom, "Unique boule de feu");
    s->degats_min = 4;
    s->degats_max = 6;
    s->pa_requis = 5;
    s->portee_min = 1;
    s->portee_max = 5;
    s->chance_echec = 5;
    s->zone = 0;
}
void init_maitresse_4(Sort* s) {
    strcpy(s->nom, "Susano");
    s->degats_min = 5;
    s->degats_max = 8;
    s->pa_requis = 7;
    s->portee_min = 1;
    s->portee_max = 7;
    s->chance_echec = 10;
    s->zone = 0;
}

// Initialisation des sorts du Savant
void init_savant_1(Sort* s) {
    strcpy(s->nom, "Bombe");
    s->degats_min = 2;
    s->degats_max = 3;
    s->pa_requis = 2;
    s->portee_min = 1;
    s->portee_max = 3;
    s->chance_echec = 5;
    s->zone = 0;
}
void init_savant_2(Sort* s) {
    strcpy(s->nom, "Canon");
    s->degats_min = 3;
    s->degats_max = 4;
    s->pa_requis = 3;
    s->portee_min = 1;
    s->portee_max = 4;
    s->chance_echec = 5;
    s->zone = 0;
}
void init_savant_3(Sort* s) {
    strcpy(s->nom, "Mitraillette");
    s->degats_min = 4;
    s->degats_max = 6;
    s->pa_requis = 5;
    s->portee_min = 1;
    s->portee_max = 5;
    s->chance_echec = 5;
    s->zone = 0;
}
void init_savant_4(Sort* s) {
    strcpy(s->nom, "Bébé dragon");
    s->degats_min = 5;
    s->degats_max = 8;
    s->pa_requis = 7;
    s->portee_min = 2;
    s->portee_max = 7;
    s->chance_echec = 10;
    s->zone = 0;
}

// Initialisation globale de tous les sorts
void init_sorts_classes() {
    init_maitresse_1(&maitresse[0]);
    init_maitresse_2(&maitresse[1]);
    init_maitresse_3(&maitresse[2]);
    init_maitresse_4(&maitresse[3]);

    init_savant_1(&savant[0]);
    init_savant_2(&savant[1]);
    init_savant_3(&savant[2]);
    init_savant_4(&savant[3]);

    // Tu peux ajouter init pour mage et archère ici
}

// Fonction pour initialiser un joueur en fonction de sa classe
void init_personnage_maitresse(struct init_joueurs* p) {
    strcpy(p->nom, "Maitresse");
    p->pv = 100;
    p->pa = 10;
    p->ligne = 0;
    p->colonne = 0;
    for (int i = 0; i < NBR_SORTS; i++) {
        p->sorts[i] = maitresse[i];
    }
}

void init_personnage_savant(struct init_joueurs* p) {
    strcpy(p->nom, "Savant");
    p->pv = 100;
    p->pa = 10;
    p->ligne = 5;
    p->colonne = 5;
    for (int i = 0; i < NBR_SORTS; i++) {
        p->sorts[i] = savant[i];
    }
}

// Distance Manhattan
int distance(int x1, int y1, int x2, int y2) {
    return abs(x1 - x2) + abs(y1 - y2);
}

// Vérifie si la cible est dans la portée du sort
int est_dans_portee(struct init_joueurs* lanceur, struct init_joueurs* cible, Sort* s) {
    int dist = distance(lanceur->ligne, lanceur->colonne, cible->ligne, cible->colonne);
    return (dist >= s->portee_min && dist <= s->portee_max);
}

// Vérifie si le personnage a assez de PA pour lancer le sort
int peut_utiliser_sort(struct init_joueurs* p, Sort* s) {
    return p->pa >= s->pa_requis;
}

// Utiliser un sort (logique de combat)
void utiliser_sort(struct init_joueurs* lanceur, init_joueurs* cible, Sort* s) {
    if (!peut_utiliser_sort(lanceur, s)) {
        printf("%s n'a pas assez de PA pour utiliser %s.\n", lanceur->nom, s->nom);
        return;
    }

    if (!est_dans_portee(lanceur, cible, s)) {
        printf("Cible hors de portée pour %s.\n", s->nom);
        return;
    }

    int chance = rand() % 100;
    if (chance < s->chance_echec) {
        printf("%s a raté %s !\n", lanceur->nom, s->nom);
        lanceur->pa -= s->pa_requis / 2;
        return;
    }

    lanceur->pa -= s->pa_requis;
    int degats = s->degats_min + rand() % (s->degats_max - s->degats_min + 1);
    cible->pv -= degats;

    printf("%s utilise %s et inflige %d dégâts à %s.\n", lanceur->nom, s->nom, degats, cible->nom);

    if (cible->pv <= 0) {
        printf("%s est mort.\n", cible->nom);
    } else {
        printf("%s a maintenant %d PV.\n", cible->nom, cible->pv);
    }
}
*/